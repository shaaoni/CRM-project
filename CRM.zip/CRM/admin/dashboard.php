<?php 

session_start(); 
if(isset($_SESSION['u_name']) && isset($_SESSION['u_pass'])){
  $u_name = $_SESSION['u_name'];
  $u_pass = $_SESSION['u_pass'];

include_once("../config/db.php");
  // echo "$u_name";
  // echo "$u_pass";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>ADMIN DASHBOARD</title>
  <meta charset="utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" type="text/css" href="./css/dashboard.css">

  <style type="text/css">
    #status_table{
      display: none;
    }
    .assign_work{
      border: 1px solid grey;
      background-color: #f7f9fa;
      width: auto;
      height: auto;
      padding: 20px;
      border-radius: 5px;
    }

    .active_button{
      background-color: blue;
      color: white;
    }
  </style>

</head>
<body>

<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Admin Dashboard</a> <?php echo $username; ?></li>
        <li><a href="user.html">User</a></li>
        <!-- <li><a href="#">Activity</a></li> -->
        <li><a href="logout.php">Log Out</a></li> -->
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs" style="height: 700px;">
      <h2>Logo</h2>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="#dashboard.php">Admin Dashboard</a></li>
        <li><a href="client.php">Clients</a></li>
        <li><a href="workers.php">Workers</a></li>
        <!-- <li><a href="projects.php">Projects</a></li> -->
        <!-- <li><a href="#">Properties</a></li> -->
        <!-- <li><a href="leads.php">Leads</a></li> -->
        <li><a href="calendar.php">Time sheet</a></li>
        <li><a href="#">Billing & Invoices</a></li>
        <!-- <li><a href="#">Agreements</a></li>
        <li><a href="#">Masters</a></li> -->
        <li><a href="logout.php">Log Out</a></li>
        <hr style="background-color: black;">
        <li><a href="profile.php">Account Settings</a></li>

      </ul><br>
     
    </div>
    <br>
    
    <div class="col-sm-9">
      <div class="well">
        <h4>Dashboard</h4>
        <ul>
        <li> Welcome : <?php  echo strtoupper($_SESSION['full_name']); ?></li>
        <li>Email: <?php echo  $_SESSION['email_id']; ?></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="well" id="active_emp" style="cursor: pointer;">
            Active Employees
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well" id="manage_task" style="cursor: pointer;">
            Manage Tasks
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well" id="tasks_list" style="cursor: pointer;">
            Tasks List
          </div>
        </div>
        <div class="col-sm-3">
          <div class="well" id="attendance" style="cursor: pointer;">
            Attendance
          </div>
        </div>
      </div>



      <div id="status_table">
        <table border="2px;" class="table table-success table-striped">
          <thead>
              <th colspan="2">ID</th>
              <th colspan="4">Name</th>
              <th colspan="4">Email</th>
              <th colspan="2">Status</th>
          </thead>
          <tbody id="tbody">
            
<?php

$sql = "SELECT * FROM workers INNER JOIN user_login ON workers.uname = user_login.uname";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  $id=0;
  while($row = mysqli_fetch_assoc($result)){
    $id=$id+1;
    $fname = $row['fname'];
    $lname = $row['lname'];
    $mail = $row['email'];
    $status = $row['status'];
    $name = $fname." ".$lname;
?>
           <tr>
             <td colspan="2"><?php echo $id; ?></td>
             <td colspan="4"><?php echo $name; ?></td>
             <td colspan="4"><?php echo $mail; ?></td>
             <?php if($status=='active'){;?>
             <td colspan="2" style="color:#3B9212;"><?php echo $status; ?></td>
           <?php };?>

            <?php if($status=='inactive'){;?>
             <td colspan="2" style="color:#D5185A;"><?php echo $status; ?></td>
           <?php };?>
           </tr> 
<?php
  }
}
?>
          </tbody>
        </table>
        <div id="pagination" style="display: flex;">
            <button id="prev">Previous</button>&nbsp
            <div id="pagination_div">
              
            </div>
          <!-- <span id="page"></span> -->
          &nbsp
          <button id="next">Next</button>
      </div>
      </div>
      <br>
      <div id="assign_task" style="display: none;">
        <div class="form-group assign_work">
        <form name="task_form" id="task_form" method="post">
          <label class="form-text text-muted">Employee ID:</label>
          <input type="text" name="e_id" class="form-control"><br>
          <lable class="form-text text-muted">Task Description:</lable> 
          <textarea id="task_desc" name="task_desc" class="form-control"></textarea><br>
          <label class="form-text text-muted">Deadline: </label>
          <input type="date" name="deadline" class="form-control"><br>
          <input type="submit" name="task_submit" value="assign" class="btn btn-primary">
          <br>
        </form>
      </div>
<?php

if(isset($_POST['task_submit'])){
  $emp_id = $_POST['e_id'];
  $task_desc = $_POST['task_desc'];
  $deadline = $_POST['deadline'];


  $sql1 = "SELECT * from workers where user_id='$emp_id' ";
  $result = mysqli_query($conn,$sql1);

  if($result){

    $emp_data = mysqli_fetch_assoc($result);
    $emp_mail = $emp_data['email'];
    // echo $emp_mail;

    $sql2 = "INSERT INTO emp_task(emp_id,email,task_desc,deadline) VALUES('$emp_id','$emp_mail','$task_desc','$deadline')";
    $result = mysqli_query($conn,$sql2);
    if($result){
      echo "assigned";
    }
    else{
      echo "Not assigned";
    }

  }
  else{
    echo "user_id doesn't match";
  }
}

?>
      </div>

      <br><br>

      <div id="task_table" style="display: none;">
        <table border="2px;" class="table table-success table-striped">
          <thead>
              <th colspan="2">Task ID</th>
              <th colspan="4">Task Description</th>
              <th colspan="4">Employee ID</th>
              <th colspan="2">Email</th>
              <th colspan="2">Date</th>
              <th colspan="2">Deadline</th>
              <th colspan="2">Action</th>
          </thead>
          <tbody id="task_body">
<?php

  $sql = "SELECT * FROM emp_task";
  $result = mysqli_query($conn,$sql);
  if(mysqli_num_rows($result)){
    while($tasks=mysqli_fetch_assoc($result)){
      $task_id = $tasks['task_id'];
      $task_desc = $tasks['task_desc'];
      $emp_id = $tasks['emp_id'];
      $email = $tasks['email'];
      $date_ddln = $tasks['deadline'];
      $date = $tasks['date'];

      $timestamp = strtotime($date);
      $formattedDate = date('d-m-Y', $timestamp);

      $timestamp_ddln = strtotime($date_ddln);
      $formattedDate_ddln = date('d-m-Y', $timestamp_ddln);
?>

  <tr>
    <td colspan="2"><?php echo $task_id; ?></td>
    <td colspan="4"><?php echo $task_desc; ?></td>
    <td colspan="4"><?php echo $emp_id; ?></td>
    <td colspan="2"><?php echo $email; ?></td>
    <td colspan="2"><?php echo $formattedDate; ?></td>
    <td colspan="2"><?php echo $formattedDate_ddln; ?></td>
    <td colspan="4"><a href="edit_task.php?tid=<?php echo $task_id; ?>">Edit</a> |
                    <a href="delete_task.php?tid=<?php echo $task_id; ?>">Delete</a>
    </td>
  </tr>

<?php
    }
  }

?>            
          </tbody>
        </table>
        <div id="t_pagination" style="display: flex;">
            <button id="t_prev">Previous</button>&nbsp
            <div id="t_pagination_div">
              
            </div>
          <!-- <span id="page"></span> -->
          &nbsp
          <button id="t_next">Next</button>
      </div>
      </div>
<br>
      <div id="attndnc_table" style="display: none;">
        <table border="2px;" class="table table-success table-striped">
          <thead>
              <th colspan="2">S. No.</th>
              <th colspan="2">Employee ID</th>
              <th colspan="4">Login Time</th>
              <th colspan="4">Logout Time</th>
              <th colspan="2">Working Hour</th>
          </thead>
          <tbody id="att_body">
            
<?php

$sql = "SELECT * FROM attendance ";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
  $id=0;
  while($row = mysqli_fetch_assoc($result)){
    $id=$id+1;
    $eid = $row['emp_id'];
    $login = $row['login'];
    $logout = $row['logout'];
    $date = $row['date'];

// Create DateTime objects for each date
$datetime1 = new DateTime($login);
$datetime2 = new DateTime($logout);

// Calculate the difference
$interval = $datetime1->diff($datetime2);

// Get the difference in days, hours, minutes, etc.
$days = $interval->days;
$hours = $interval->h;
$minutes = $interval->i;
$seconds = $interval->s;

?>
           <tr>
             <td colspan="2"><?php echo $id; ?></td>
             <td colspan="2"><?php echo $eid; ?></td>
             <td colspan="4"><?php echo $login; ?></td>
             <td colspan="4"><?php echo $logout; ?></td>
             <td colspan="2"><?php echo $minutes; ?></td>
           </tr> 
<?php
  }
}
?>
          </tbody>
        </table>
        <!-- <div id="pagination" style="display: flex;">
            <button id="prev">Previous</button>&nbsp
            <div id="pagination_div">
              
            </div>
          
          &nbsp
          <button id="next">Next</button>
      </div> -->
      </div>
     
    </div>
  </div>
</div>

</body>
</html>

<script type="text/javascript">
  
$(document).ready(function(){
    $("#active_emp").click(function(){
      $("#status_table").toggle(350);
    });
});

$(document).ready(function(){
    $("#manage_task").click(function(){
      $("#assign_task").toggle(350);
    });
});

$(document).ready(function(){
    $("#tasks_list").click(function(){
      $("#task_table").toggle(350);
    });
});

$(document).ready(function(){
    $("#attendance").click(function(){
      $("#attndnc_table").toggle(350);
    });
});

</script>

<script type="text/javascript">
  $(document).ready(function() {
    var rowsShown = 2; // Number of rows to display per page
    var rowsTotal = $('#tbody tr').length; // Total number of rows
    var numPages = rowsTotal / rowsShown; // Calculate the number of pages

    for (var i = 0; i < numPages; i++) {
        var pageNum = i + 1;
        $('#pagination_div').append('<button class="page-btn" rel="' + i + '">' + pageNum + '</button> ');
    }

    $('#tbody tr').hide(); // Hide all rows
    $('#tbody tr').slice(0, rowsShown).show(); // Show the first set of rows

    $('#pagination_div button:first').addClass('active_button'); // Mark the first page as active

    $('#pagination_div button').click(function() {
        $('#pagination_div button').removeClass('active_button'); // Remove active class from all buttons
        $(this).addClass('active_button'); // Add active class to the clicked button

        var pageNum = $(this).attr('rel');
        var start = pageNum * rowsShown;
        var end = start + rowsShown;

        $('#tbody tr').hide(); // Hide all rows
        $('#tbody tr').slice(start, end).show(); // Show the selected rows
    });

    $('#next').click(function () {
    var currentPage = $('.page-btn.active_button').attr('rel');
    //console.log(parseInt(currentPage));
    if (currentPage < numPages - 1) {
        var nextPage = parseInt(currentPage) + 1;
        var back_row = parseInt(currentPage);
        $('#pagination_div button').removeClass('active_button');
        $('#pagination_div button[rel="' + nextPage + '"]').addClass('active_button');
        var start = nextPage * rowsShown;
        var end = Math.min((start + rowsShown), rowsTotal);
       
        $('#tbody tr').hide();
        $('#tbody tr').slice(start, end).show();
    }
    
});

      $('#prev').click(function () {
      var currentPage = $('.page-btn.active_button').attr('rel');
      //console.log(parseInt(currentPage));
      if (currentPage > 0) {
          var prevPage = parseInt(currentPage) - 1;
          $('#pagination_div button').removeClass('active_button');
          $('#pagination_div button[rel="' + prevPage + '"]').addClass('active_button');
          var start = prevPage * rowsShown;
          var end = start + rowsShown;

          $('#tbody tr').hide();
          $('#tbody tr').slice(start, end).show();
      }
      
    });
});

</script>

<script type="text/javascript">
  $(document).ready(function() {
    var rowsShown = 2; // Number of rows to display per page
    var rowsTotal = $('#task_body tr').length; // Total number of rows
    var numPages = rowsTotal / rowsShown; // Calculate the number of pages

    for (var i = 0; i < numPages; i++) {
        var pageNum = i + 1;
        $('#t_pagination_div').append('<button class="page-btn" rel="' + i + '">' + pageNum + '</button> ');
    }

    $('#task_body tr').hide(); // Hide all rows
    $('#task_body tr').slice(0, rowsShown).show(); // Show the first set of rows

    $('#t_pagination_div button:first').addClass('active_button'); // Mark the first page as active

    $('#t_pagination_div button').click(function() {
        $('#t_pagination_div button').removeClass('active_button'); // Remove active class from all buttons
        $(this).addClass('active_button'); // Add active class to the clicked button

        var pageNum = $(this).attr('rel');
        var start = pageNum * rowsShown;
        var end = start + rowsShown;

        $('#task_body tr').hide(); // Hide all rows
        $('#task_body tr').slice(start, end).show(); // Show the selected rows
    });

    $('#t_next').click(function () {
    var currentPage = $('.page-btn.active_button').attr('rel');
    //console.log(parseInt(currentPage));
    if (currentPage < numPages - 1) {
        var nextPage = parseInt(currentPage) + 1;
        var back_row = parseInt(currentPage);
        $('#t_pagination_div button').removeClass('active_button');
        $('#t_pagination_div button[rel="' + nextPage + '"]').addClass('active_button');
        var start = nextPage * rowsShown;
        var end = Math.min((start + rowsShown), rowsTotal);
       
        $('#task_body tr').hide();
        $('#task_body tr').slice(start, end).show();
    }
    
});

      $('#t_prev').click(function () {
        var currentPage = $('.page-btn.active_button').attr('rel');
        //console.log(parseInt(currentPage));
        if (currentPage > 0) {
            var prevPage = parseInt(currentPage) - 1;
            $('#t_pagination_div button').removeClass('active_button');
        $('#t_pagination_div button[rel="' + prevPage + '"]').addClass('active_button');
            var start = prevPage * rowsShown;
            var end = start + rowsShown;

            $('#task_body tr').hide();
            $('#task_body tr').slice(start, end).show();
        }
    });

});

</script>


<?php
}
else{

  echo "401 login failed.<br>";
  echo "you haven't logged in yet.<br><br>";
?>

<a href="index.php"> Login here.</a>

<?php
}

?>
