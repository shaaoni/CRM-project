<form method="post">
ID: &nbsp&nbsp <input type="text" name="id_update" value="<?php echo $id; ?>" ><br><br>

User ID: &nbsp&nbsp 
<input type="text" name="userId_update" value="<?php echo $user_id; ?>" ><br><br>

Username: &nbsp&nbsp <input type="text" name="uname_update" value="<?php echo $uname; ?>" ><br><br>

First Name: &nbsp&nbsp 
<input type="text" name="fname_update" value="<?php echo $fname; ?>" ><br><br>

Last Name: &nbsp&nbsp 
<input type="text" name="lname_update" value="<?php echo $lname; ?>" ><br><br>

Contacts: &nbsp&nbsp 
<input type="text" name="contacts_update" value="<?php echo $contacts; ?>" ><br><br>

Address: &nbsp&nbsp 
 <input type="text" name="address_update" value="<?php echo $address; ?>" ><br><br>

Date of Joining: &nbsp&nbsp 
<input type="text" name="doj_update" value="<?php echo $doj; ?>" ><br><br>

Email: &nbsp&nbsp <input type="text" name="email_update" value="<?php echo $email; ?>" ><br><br>

Qualification: &nbsp&nbsp
 <input type="text" name="qua_update" value="<?php echo $qualification; ?>" ><br><br>

Designation: &nbsp&nbsp 
 <input type="text" name="designation_update" value="<?php echo $designation; ?>" ><br><br>

 <input type="submit" name="submit" value="UPDATE">
      </form>